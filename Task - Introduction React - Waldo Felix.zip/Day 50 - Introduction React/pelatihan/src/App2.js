import Contact from "./Contact";

function App() {
    return (
        <div className="App">
            <Contact />
        </div>
    );
}

export default App;
